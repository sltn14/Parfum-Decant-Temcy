const axios = require('axios');

const RAJAONGKIR_KEY = process.env.RAJAONGKIR_KEY || 'YOUR_API_KEY';
// RajaOngkir V2 (Komerce): https://rajaongkir.komerce.id/api/v1 (header `key`)
const BASE_URL = 'https://rajaongkir.komerce.id/api/v1';
// ID lokasi asal toko dari endpoint pencarian destinasi (mis. kecamatan toko). Wajib saat memakai key asli.
const ORIGIN_ID = process.env.RAJAONGKIR_ORIGIN_ID || '';
const REQUEST_TIMEOUT_MS = 10000;

const MOCK_PROVINCES = [
  { province_id: '1', province: 'Bali' },
  { province_id: '2', province: 'Bangka Belitung' },
  { province_id: '3', province: 'Banten' },
  { province_id: '4', province: 'Bengkulu' },
  { province_id: '5', province: 'DI Yogyakarta' },
  { province_id: '6', province: 'DKI Jakarta' },
  { province_id: '7', province: 'Gorontalo' },
  { province_id: '8', province: 'Jambi' },
  { province_id: '9', province: 'Jawa Barat' },
  { province_id: '10', province: 'Jawa Tengah' },
  { province_id: '11', province: 'Jawa Timur' },
  { province_id: '12', province: 'Kalimantan Barat' },
  { province_id: '13', province: 'Kalimantan Selatan' },
  { province_id: '14', province: 'Kalimantan Tengah' },
  { province_id: '15', province: 'Kalimantan Timur' },
  { province_id: '16', province: 'Kalimantan Utara' },
  { province_id: '17', province: 'Kepulauan Riau' },
  { province_id: '18', province: 'Lampung' },
  { province_id: '19', province: 'Maluku' },
  { province_id: '20', province: 'Maluku Utara' },
  { province_id: '21', province: 'Nusa Tenggara Barat' },
  { province_id: '22', province: 'Nusa Tenggara Timur' },
  { province_id: '23', province: 'Papua' },
  { province_id: '24', province: 'Papua Barat' },
  { province_id: '25', province: 'Riau' },
  { province_id: '26', province: 'Sulawesi Barat' },
  { province_id: '27', province: 'Sulawesi Selatan' },
  { province_id: '28', province: 'Sulawesi Tengah' },
  { province_id: '29', province: 'Sulawesi Tenggara' },
  { province_id: '30', province: 'Sulawesi Utara' },
  { province_id: '31', province: 'Sumatera Barat' },
  { province_id: '32', province: 'Sumatera Selatan' },
  { province_id: '33', province: 'Sumatera Utara' },
  { province_id: '34', province: 'Aceh' },
];

const MOCK_CITIES = {
  '1': [
    { city_id: '17', city_name: 'Badung', postal_code: '80351' },
    { city_id: '18', city_name: 'Bangli', postal_code: '80619' },
    { city_id: '19', city_name: 'Buleleng', postal_code: '81100' },
    { city_id: '20', city_name: 'Denpasar', postal_code: '80114' },
    { city_id: '21', city_name: 'Gianyar', postal_code: '80500' },
    { city_id: '22', city_name: 'Karangasem', postal_code: '80801' },
    { city_id: '23', city_name: 'Klungkung', postal_code: '80712' },
    { city_id: '24', city_name: 'Tabanan', postal_code: '82100' },
    { city_id: '25', city_name: 'Jembrana', postal_code: '82211' },
  ],
  '2': [
    { city_id: '26', city_name: 'Bangka', postal_code: '33100' },
    { city_id: '27', city_name: 'Bangka Barat', postal_code: '33315' },
    { city_id: '28', city_name: 'Bangka Selatan', postal_code: '33700' },
    { city_id: '29', city_name: 'Bangka Tengah', postal_code: '33670' },
    { city_id: '30', city_name: 'Belitung', postal_code: '33400' },
    { city_id: '31', city_name: 'Belitung Timur', postal_code: '33511' },
    { city_id: '32', city_name: 'Pangkal Pinang', postal_code: '33100' },
  ],
  '3': [
    { city_id: '33', city_name: 'Cilegon', postal_code: '42417' },
    { city_id: '34', city_name: 'Lebak', postal_code: '42300' },
    { city_id: '35', city_name: 'Pandeglang', postal_code: '42200' },
    { city_id: '36', city_name: 'Serang', postal_code: '42100' },
    { city_id: '37', city_name: 'Tangerang', postal_code: '15100' },
    { city_id: '38', city_name: 'Tangerang Selatan', postal_code: '15310' },
    { city_id: '39', city_name: 'Kota Serang', postal_code: '42100' },
  ],
  '4': [
    { city_id: '40', city_name: 'Bengkulu', postal_code: '38100' },
    { city_id: '41', city_name: 'Bengkulu Selatan', postal_code: '38500' },
    { city_id: '42', city_name: 'Bengkulu Tengah', postal_code: '38300' },
    { city_id: '43', city_name: 'Bengkulu Utara', postal_code: '38600' },
    { city_id: '44', city_name: 'Kaur', postal_code: '38951' },
    { city_id: '45', city_name: 'Kepahiang', postal_code: '38700' },
    { city_id: '46', city_name: 'Mukomuko', postal_code: '38761' },
    { city_id: '47', city_name: 'Rejang Lebong', postal_code: '39100' },
    { city_id: '48', city_name: 'Seluma', postal_code: '38851' },
  ],
  '5': [
    { city_id: '49', city_name: 'Bantul', postal_code: '55700' },
    { city_id: '50', city_name: 'Gunungkidul', postal_code: '55800' },
    { city_id: '51', city_name: 'Kulon Progo', postal_code: '55600' },
    { city_id: '52', city_name: 'Sleman', postal_code: '55500' },
    { city_id: '53', city_name: 'Yogyakarta', postal_code: '55100' },
  ],
  '6': [
    { city_id: '150', city_name: 'Jakarta Barat', postal_code: '11220' },
    { city_id: '151', city_name: 'Jakarta Pusat', postal_code: '10540' },
    { city_id: '152', city_name: 'Jakarta Selatan', postal_code: '12010' },
    { city_id: '153', city_name: 'Jakarta Timur', postal_code: '13330' },
    { city_id: '154', city_name: 'Jakarta Utara', postal_code: '14140' },
    { city_id: '155', city_name: 'Kepulauan Seribu', postal_code: '14550' },
  ],
  '7': [
    { city_id: '156', city_name: 'Boalemo', postal_code: '96300' },
    { city_id: '157', city_name: 'Bone Bolango', postal_code: '96511' },
    { city_id: '158', city_name: 'Gorontalo', postal_code: '96100' },
    { city_id: '159', city_name: 'Gorontalo Utara', postal_code: '96611' },
    { city_id: '160', city_name: 'Pohuwato', postal_code: '96400' },
  ],
  '8': [
    { city_id: '161', city_name: 'Batanghari', postal_code: '36600' },
    { city_id: '162', city_name: 'Bungo', postal_code: '37200' },
    { city_id: '163', city_name: 'Jambi', postal_code: '36100' },
    { city_id: '164', city_name: 'Kerinci', postal_code: '37100' },
    { city_id: '165', city_name: 'Merangin', postal_code: '37300' },
    { city_id: '166', city_name: 'Muaro Jambi', postal_code: '36361' },
    { city_id: '167', city_name: 'Sarolangun', postal_code: '37400' },
    { city_id: '168', city_name: 'Sungai Penuh', postal_code: '37100' },
    { city_id: '169', city_name: 'Tanjung Jabung Barat', postal_code: '36500' },
    { city_id: '170', city_name: 'Tanjung Jabung Timur', postal_code: '36700' },
    { city_id: '171', city_name: 'Tebo', postal_code: '37500' },
  ],
  '9': [
    { city_id: '20', city_name: 'Bandung', postal_code: '40111' },
    { city_id: '21', city_name: 'Bandung Barat', postal_code: '40700' },
    { city_id: '22', city_name: 'Bekasi', postal_code: '17100' },
    { city_id: '23', city_name: 'Bogor', postal_code: '16100' },
    { city_id: '24', city_name: 'Ciamis', postal_code: '46200' },
    { city_id: '25', city_name: 'Cianjur', postal_code: '43200' },
    { city_id: '26', city_name: 'Cimahi', postal_code: '40500' },
    { city_id: '27', city_name: 'Cirebon', postal_code: '45100' },
    { city_id: '28', city_name: 'Depok', postal_code: '16400' },
    { city_id: '29', city_name: 'Garut', postal_code: '44100' },
    { city_id: '30', city_name: 'Indramayu', postal_code: '45200' },
    { city_id: '31', city_name: 'Karawang', postal_code: '41300' },
    { city_id: '32', city_name: 'Kuningan', postal_code: '45500' },
    { city_id: '33', city_name: 'Majalengka', postal_code: '45400' },
    { city_id: '34', city_name: 'Purwakarta', postal_code: '41100' },
    { city_id: '35', city_name: 'Subang', postal_code: '41200' },
    { city_id: '36', city_name: 'Sukabumi', postal_code: '43100' },
    { city_id: '37', city_name: 'Sumedang', postal_code: '45300' },
    { city_id: '38', city_name: 'Tasikmalaya', postal_code: '46100' },
  ],
  '10': [
    { city_id: '399', city_name: 'Semarang', postal_code: '50111' },
    { city_id: '400', city_name: 'Banjarnegara', postal_code: '53400' },
    { city_id: '401', city_name: 'Banyumas', postal_code: '53100' },
    { city_id: '402', city_name: 'Batang', postal_code: '51200' },
    { city_id: '403', city_name: 'Blora', postal_code: '58200' },
    { city_id: '404', city_name: 'Boyolali', postal_code: '57300' },
    { city_id: '405', city_name: 'Brebes', postal_code: '52200' },
    { city_id: '406', city_name: 'Cilacap', postal_code: '53200' },
    { city_id: '407', city_name: 'Demak', postal_code: '59500' },
    { city_id: '408', city_name: 'Grobogan', postal_code: '58100' },
    { city_id: '409', city_name: 'Jepara', postal_code: '59400' },
    { city_id: '410', city_name: 'Karanganyar', postal_code: '57700' },
    { city_id: '411', city_name: 'Kebumen', postal_code: '54300' },
    { city_id: '412', city_name: 'Kendal', postal_code: '51300' },
    { city_id: '413', city_name: 'Klaten', postal_code: '57400' },
    { city_id: '414', city_name: 'Kudus', postal_code: '59300' },
    { city_id: '415', city_name: 'Magelang', postal_code: '56100' },
    { city_id: '416', city_name: 'Pati', postal_code: '59100' },
    { city_id: '417', city_name: 'Pekalongan', postal_code: '51100' },
    { city_id: '418', city_name: 'Pemalang', postal_code: '52300' },
    { city_id: '419', city_name: 'Purbalingga', postal_code: '53300' },
    { city_id: '420', city_name: 'Purworejo', postal_code: '54100' },
    { city_id: '421', city_name: 'Rembang', postal_code: '59200' },
    { city_id: '422', city_name: 'Salatiga', postal_code: '50700' },
    { city_id: '423', city_name: 'Solo', postal_code: '57100' },
    { city_id: '424', city_name: 'Sragen', postal_code: '57200' },
    { city_id: '425', city_name: 'Sukoharjo', postal_code: '57500' },
    { city_id: '426', city_name: 'Tegal', postal_code: '52100' },
    { city_id: '427', city_name: 'Temanggung', postal_code: '56200' },
    { city_id: '428', city_name: 'Wonogiri', postal_code: '57600' },
    { city_id: '429', city_name: 'Wonosobo', postal_code: '56300' },
  ],
  '11': [
    { city_id: '444', city_name: 'Surabaya', postal_code: '60111' },
    { city_id: '42', city_name: 'Malang', postal_code: '65100' },
    { city_id: '43', city_name: 'Banyuwangi', postal_code: '68400' },
    { city_id: '44', city_name: 'Blitar', postal_code: '66100' },
    { city_id: '45', city_name: 'Bojonegoro', postal_code: '62100' },
    { city_id: '46', city_name: 'Bondowoso', postal_code: '68200' },
    { city_id: '47', city_name: 'Gresik', postal_code: '61100' },
    { city_id: '48', city_name: 'Jember', postal_code: '68100' },
    { city_id: '49', city_name: 'Jombang', postal_code: '61400' },
    { city_id: '50', city_name: 'Kediri', postal_code: '64100' },
    { city_id: '51', city_name: 'Lamongan', postal_code: '62200' },
    { city_id: '52', city_name: 'Lumajang', postal_code: '67300' },
    { city_id: '53', city_name: 'Madiun', postal_code: '63100' },
    { city_id: '54', city_name: 'Magetan', postal_code: '63300' },
    { city_id: '55', city_name: 'Mojokerto', postal_code: '61300' },
    { city_id: '56', city_name: 'Nganjuk', postal_code: '64400' },
    { city_id: '57', city_name: 'Ngawi', postal_code: '63200' },
    { city_id: '58', city_name: 'Pacitan', postal_code: '63500' },
    { city_id: '59', city_name: 'Pamekasan', postal_code: '69300' },
    { city_id: '60', city_name: 'Pasuruan', postal_code: '67100' },
    { city_id: '61', city_name: 'Ponorogo', postal_code: '63400' },
    { city_id: '62', city_name: 'Probolinggo', postal_code: '67200' },
    { city_id: '63', city_name: 'Sampang', postal_code: '69200' },
    { city_id: '64', city_name: 'Sidoarjo', postal_code: '61200' },
    { city_id: '65', city_name: 'Situbondo', postal_code: '68300' },
    { city_id: '66', city_name: 'Sumenep', postal_code: '69400' },
    { city_id: '67', city_name: 'Trenggalek', postal_code: '66300' },
    { city_id: '68', city_name: 'Tuban', postal_code: '62300' },
    { city_id: '69', city_name: 'Tulungagung', postal_code: '66200' },
  ],
  '12': [
    { city_id: '200', city_name: 'Ketapang', postal_code: '78800' },
    { city_id: '201', city_name: 'Kubu Raya', postal_code: '78300' },
    { city_id: '202', city_name: 'Landak', postal_code: '78300' },
    { city_id: '203', city_name: 'Melawi', postal_code: '78600' },
    { city_id: '204', city_name: 'Mempawah', postal_code: '78900' },
    { city_id: '205', city_name: 'Pontianak', postal_code: '78100' },
    { city_id: '206', city_name: 'Sambas', postal_code: '79400' },
    { city_id: '207', city_name: 'Sanggau', postal_code: '78500' },
    { city_id: '208', city_name: 'Sekadau', postal_code: '79500' },
    { city_id: '209', city_name: 'Singkawang', postal_code: '79100' },
    { city_id: '210', city_name: 'Sintang', postal_code: '78600' },
  ],
  '13': [
    { city_id: '211', city_name: 'Balangan', postal_code: '71600' },
    { city_id: '212', city_name: 'Banjar', postal_code: '70600' },
    { city_id: '213', city_name: 'Banjarmasin', postal_code: '70100' },
    { city_id: '214', city_name: 'Barito Kuala', postal_code: '70500' },
    { city_id: '215', city_name: 'Hulu Sungai Selatan', postal_code: '71200' },
    { city_id: '216', city_name: 'Hulu Sungai Tengah', postal_code: '71300' },
    { city_id: '217', city_name: 'Hulu Sungai Utara', postal_code: '71400' },
    { city_id: '218', city_name: 'Kotabaru', postal_code: '72100' },
    { city_id: '219', city_name: 'Tabalong', postal_code: '71500' },
    { city_id: '220', city_name: 'Tanah Bumbu', postal_code: '72100' },
    { city_id: '221', city_name: 'Tanah Laut', postal_code: '70800' },
    { city_id: '222', city_name: 'Tapin', postal_code: '71100' },
  ],
  '14': [
    { city_id: '223', city_name: 'Barito Selatan', postal_code: '73700' },
    { city_id: '224', city_name: 'Barito Timur', postal_code: '73600' },
    { city_id: '225', city_name: 'Barito Utara', postal_code: '73800' },
    { city_id: '226', city_name: 'Gunung Mas', postal_code: '74500' },
    { city_id: '227', city_name: 'Kapuas', postal_code: '73500' },
    { city_id: '228', city_name: 'Katingan', postal_code: '74411' },
    { city_id: '229', city_name: 'Kotawaringin Barat', postal_code: '74100' },
    { city_id: '230', city_name: 'Kotawaringin Timur', postal_code: '74300' },
    { city_id: '231', city_name: 'Lamandau', postal_code: '74100' },
    { city_id: '232', city_name: 'Murung Raya', postal_code: '73900' },
    { city_id: '233', city_name: 'Palangkaraya', postal_code: '73100' },
    { city_id: '234', city_name: 'Pulang Pisau', postal_code: '74800' },
    { city_id: '235', city_name: 'Seruyan', postal_code: '74200' },
    { city_id: '236', city_name: 'Sukamara', postal_code: '74100' },
  ],
  '15': [
    { city_id: '237', city_name: 'Balikpapan', postal_code: '76100' },
    { city_id: '238', city_name: 'Berau', postal_code: '77300' },
    { city_id: '239', city_name: 'Bontang', postal_code: '75300' },
    { city_id: '240', city_name: 'Kutai Barat', postal_code: '77500' },
    { city_id: '241', city_name: 'Kutai Kartanegara', postal_code: '75600' },
    { city_id: '242', city_name: 'Kutai Timur', postal_code: '75600' },
    { city_id: '243', city_name: 'Mahakam Ulu', postal_code: '75500' },
    { city_id: '244', city_name: 'Paser', postal_code: '76200' },
    { city_id: '245', city_name: 'Penajam Paser Utara', postal_code: '76100' },
    { city_id: '246', city_name: 'Samarinda', postal_code: '75100' },
  ],
  '16': [
    { city_id: '247', city_name: 'Bulungan', postal_code: '77300' },
    { city_id: '248', city_name: 'Malinau', postal_code: '77500' },
    { city_id: '249', city_name: 'Nunukan', postal_code: '77400' },
    { city_id: '250', city_name: 'Tana Tidung', postal_code: '77300' },
    { city_id: '251', city_name: 'Tarakan', postal_code: '77100' },
  ],
  '17': [
    { city_id: '252', city_name: 'Batam', postal_code: '29400' },
    { city_id: '253', city_name: 'Bintan', postal_code: '29100' },
    { city_id: '254', city_name: 'Karimun', postal_code: '29600' },
    { city_id: '255', city_name: 'Kepulauan Anambas', postal_code: '29900' },
    { city_id: '256', city_name: 'Lingga', postal_code: '29800' },
    { city_id: '257', city_name: 'Natuna', postal_code: '29700' },
    { city_id: '258', city_name: 'Tanjung Pinang', postal_code: '29100' },
  ],
  '18': [
    { city_id: '259', city_name: 'Bandar Lampung', postal_code: '35100' },
    { city_id: '260', city_name: 'Lampung Barat', postal_code: '35700' },
    { city_id: '261', city_name: 'Lampung Selatan', postal_code: '35300' },
    { city_id: '262', city_name: 'Lampung Tengah', postal_code: '34100' },
    { city_id: '263', city_name: 'Lampung Timur', postal_code: '34300' },
    { city_id: '264', city_name: 'Lampung Utara', postal_code: '34500' },
    { city_id: '265', city_name: 'Mesuji', postal_code: '34900' },
    { city_id: '266', city_name: 'Metro', postal_code: '34100' },
    { city_id: '267', city_name: 'Pesawaran', postal_code: '35300' },
    { city_id: '268', city_name: 'Pesisir Barat', postal_code: '35800' },
    { city_id: '269', city_name: 'Pringsewu', postal_code: '35300' },
    { city_id: '270', city_name: 'Tanggamus', postal_code: '35300' },
    { city_id: '271', city_name: 'Tulang Bawang', postal_code: '34500' },
    { city_id: '272', city_name: 'Way Kanan', postal_code: '34700' },
  ],
  '19': [
    { city_id: '273', city_name: 'Ambon', postal_code: '97100' },
    { city_id: '274', city_name: 'Buru', postal_code: '97300' },
    { city_id: '275', city_name: 'Buru Selatan', postal_code: '97352' },
    { city_id: '276', city_name: 'Kepulauan Aru', postal_code: '97600' },
    { city_id: '277', city_name: 'Maluku Barat Daya', postal_code: '97900' },
    { city_id: '278', city_name: 'Maluku Tengah', postal_code: '97500' },
    { city_id: '279', city_name: 'Maluku Tenggara', postal_code: '97600' },
    { city_id: '280', city_name: 'Maluku Tenggara Barat', postal_code: '97700' },
    { city_id: '281', city_name: 'Seram Bagian Barat', postal_code: '97400' },
    { city_id: '282', city_name: 'Seram Bagian Timur', postal_code: '97550' },
    { city_id: '283', city_name: 'Tual', postal_code: '97600' },
  ],
  '20': [
    { city_id: '284', city_name: 'Halmahera Barat', postal_code: '97753' },
    { city_id: '285', city_name: 'Halmahera Selatan', postal_code: '97800' },
    { city_id: '286', city_name: 'Halmahera Tengah', postal_code: '97853' },
    { city_id: '287', city_name: 'Halmahera Timur', postal_code: '97753' },
    { city_id: '288', city_name: 'Halmahera Utara', postal_code: '97762' },
    { city_id: '289', city_name: 'Kepulauan Sula', postal_code: '97900' },
    { city_id: '290', city_name: 'Pulau Morotai', postal_code: '97771' },
    { city_id: '291', city_name: 'Pulau Taliabu', postal_code: '97900' },
    { city_id: '292', city_name: 'Ternate', postal_code: '97700' },
    { city_id: '293', city_name: 'Tidore Kepulauan', postal_code: '97800' },
  ],
  '21': [
    { city_id: '294', city_name: 'Bima', postal_code: '84100' },
    { city_id: '295', city_name: 'Dompu', postal_code: '84200' },
    { city_id: '296', city_name: 'Lombok Barat', postal_code: '83300' },
    { city_id: '297', city_name: 'Lombok Tengah', postal_code: '83500' },
    { city_id: '298', city_name: 'Lombok Timur', postal_code: '83600' },
    { city_id: '299', city_name: 'Lombok Utara', postal_code: '83300' },
    { city_id: '300', city_name: 'Mataram', postal_code: '83100' },
    { city_id: '301', city_name: 'Sumbawa', postal_code: '84300' },
    { city_id: '302', city_name: 'Sumbawa Barat', postal_code: '84400' },
  ],
  '22': [
    { city_id: '303', city_name: 'Alor', postal_code: '85800' },
    { city_id: '304', city_name: 'Belu', postal_code: '85700' },
    { city_id: '305', city_name: 'Ende', postal_code: '86300' },
    { city_id: '306', city_name: 'Flores Timur', postal_code: '86200' },
    { city_id: '307', city_name: 'Kupang', postal_code: '85100' },
    { city_id: '308', city_name: 'Lembata', postal_code: '86600' },
    { city_id: '309', city_name: 'Manggarai', postal_code: '86500' },
    { city_id: '310', city_name: 'Manggarai Barat', postal_code: '86554' },
    { city_id: '311', city_name: 'Manggarai Timur', postal_code: '86500' },
    { city_id: '312', city_name: 'Nagekeo', postal_code: '86400' },
    { city_id: '313', city_name: 'Ngada', postal_code: '86400' },
    { city_id: '314', city_name: 'Rote Ndao', postal_code: '85900' },
    { city_id: '315', city_name: 'Sabu Raijua', postal_code: '85200' },
    { city_id: '316', city_name: 'Sikka', postal_code: '86100' },
    { city_id: '317', city_name: 'Sumba Barat', postal_code: '87200' },
    { city_id: '318', city_name: 'Sumba Barat Daya', postal_code: '87250' },
    { city_id: '319', city_name: 'Sumba Tengah', postal_code: '87300' },
    { city_id: '320', city_name: 'Sumba Timur', postal_code: '87100' },
    { city_id: '321', city_name: 'Timor Tengah Selatan', postal_code: '85500' },
    { city_id: '322', city_name: 'Timor Tengah Utara', postal_code: '85600' },
  ],
  '23': [
    { city_id: '323', city_name: 'Asmat', postal_code: '99700' },
    { city_id: '324', city_name: 'Biak Numfor', postal_code: '98100' },
    { city_id: '325', city_name: 'Boven Digoel', postal_code: '99600' },
    { city_id: '326', city_name: 'Jayapura', postal_code: '99100' },
    { city_id: '327', city_name: 'Jayawijaya', postal_code: '99500' },
    { city_id: '328', city_name: 'Keerom', postal_code: '99450' },
    { city_id: '329', city_name: 'Kepulauan Yapen', postal_code: '98200' },
    { city_id: '330', city_name: 'Mappi', postal_code: '99700' },
    { city_id: '331', city_name: 'Merauke', postal_code: '99600' },
    { city_id: '332', city_name: 'Mimika', postal_code: '99900' },
    { city_id: '333', city_name: 'Nabire', postal_code: '98800' },
    { city_id: '334', city_name: 'Paniai', postal_code: '98900' },
    { city_id: '335', city_name: 'Pegunungan Bintang', postal_code: '99573' },
    { city_id: '336', city_name: 'Puncak', postal_code: '99562' },
    { city_id: '337', city_name: 'Puncak Jaya', postal_code: '99561' },
    { city_id: '338', city_name: 'Sarmi', postal_code: '99300' },
    { city_id: '339', city_name: 'Supiori', postal_code: '98163' },
    { city_id: '340', city_name: 'Tolikara', postal_code: '99571' },
    { city_id: '341', city_name: 'Waropen', postal_code: '98264' },
    { city_id: '342', city_name: 'Yahukimo', postal_code: '99572' },
    { city_id: '343', city_name: 'Yalimo', postal_code: '99574' },
  ],
  '24': [
    { city_id: '344', city_name: 'Fakfak', postal_code: '98600' },
    { city_id: '345', city_name: 'Kaimana', postal_code: '98500' },
    { city_id: '346', city_name: 'Manokwari', postal_code: '98300' },
    { city_id: '347', city_name: 'Manokwari Selatan', postal_code: '98350' },
    { city_id: '348', city_name: 'Maybrat', postal_code: '98400' },
    { city_id: '349', city_name: 'Pegunungan Arfak', postal_code: '98371' },
    { city_id: '350', city_name: 'Raja Ampat', postal_code: '98489' },
    { city_id: '351', city_name: 'Sorong', postal_code: '98400' },
    { city_id: '352', city_name: 'Sorong Selatan', postal_code: '98453' },
    { city_id: '353', city_name: 'Tambrauw', postal_code: '98462' },
    { city_id: '354', city_name: 'Teluk Bintuni', postal_code: '98551' },
    { city_id: '355', city_name: 'Teluk Wondama', postal_code: '98252' },
  ],
  '25': [
    { city_id: '356', city_name: 'Bengkalis', postal_code: '28700' },
    { city_id: '357', city_name: 'Dumai', postal_code: '28800' },
    { city_id: '358', city_name: 'Indragiri Hilir', postal_code: '29200' },
    { city_id: '359', city_name: 'Indragiri Hulu', postal_code: '29300' },
    { city_id: '360', city_name: 'Kampar', postal_code: '28400' },
    { city_id: '361', city_name: 'Kepulauan Meranti', postal_code: '28700' },
    { city_id: '362', city_name: 'Kuantan Singingi', postal_code: '29500' },
    { city_id: '363', city_name: 'Pekanbaru', postal_code: '28100' },
    { city_id: '364', city_name: 'Pelalawan', postal_code: '28300' },
    { city_id: '365', city_name: 'Rokan Hilir', postal_code: '28900' },
    { city_id: '366', city_name: 'Rokan Hulu', postal_code: '28500' },
    { city_id: '367', city_name: 'Siak', postal_code: '28670' },
  ],
  '26': [
    { city_id: '368', city_name: 'Majene', postal_code: '91400' },
    { city_id: '369', city_name: 'Mamasa', postal_code: '91300' },
    { city_id: '370', city_name: 'Mamuju', postal_code: '91500' },
    { city_id: '371', city_name: 'Mamuju Tengah', postal_code: '91551' },
    { city_id: '372', city_name: 'Mamuju Utara', postal_code: '91571' },
    { city_id: '373', city_name: 'Polewali Mandar', postal_code: '91300' },
  ],
  '27': [
    { city_id: '374', city_name: 'Bantaeng', postal_code: '92400' },
    { city_id: '375', city_name: 'Barru', postal_code: '90700' },
    { city_id: '376', city_name: 'Bone', postal_code: '92700' },
    { city_id: '377', city_name: 'Bulukumba', postal_code: '92500' },
    { city_id: '378', city_name: 'Enrekang', postal_code: '91700' },
    { city_id: '379', city_name: 'Gowa', postal_code: '92100' },
    { city_id: '380', city_name: 'Jeneponto', postal_code: '92300' },
    { city_id: '381', city_name: 'Kepulauan Selayar', postal_code: '92800' },
    { city_id: '382', city_name: 'Luwu', postal_code: '91900' },
    { city_id: '383', city_name: 'Luwu Timur', postal_code: '92962' },
    { city_id: '384', city_name: 'Luwu Utara', postal_code: '92900' },
    { city_id: '385', city_name: 'Makassar', postal_code: '90100' },
    { city_id: '386', city_name: 'Maros', postal_code: '90500' },
    { city_id: '387', city_name: 'Palopo', postal_code: '91900' },
    { city_id: '388', city_name: 'Pangkajene Dan Kepulauan', postal_code: '90600' },
    { city_id: '389', city_name: 'Pinrang', postal_code: '91200' },
    { city_id: '390', city_name: 'Sidenreng Rappang', postal_code: '91600' },
    { city_id: '391', city_name: 'Sinjai', postal_code: '92600' },
    { city_id: '392', city_name: 'Soppeng', postal_code: '90800' },
    { city_id: '393', city_name: 'Takalar', postal_code: '92200' },
    { city_id: '394', city_name: 'Tana Toraja', postal_code: '91800' },
    { city_id: '395', city_name: 'Toraja Utara', postal_code: '91800' },
    { city_id: '396', city_name: 'Wajo', postal_code: '90900' },
  ],
  '28': [
    { city_id: '397', city_name: 'Banggai', postal_code: '94700' },
    { city_id: '398', city_name: 'Banggai Kepulauan', postal_code: '94800' },
    { city_id: '399', city_name: 'Banggai Laut', postal_code: '94800' },
    { city_id: '400', city_name: 'Buol', postal_code: '94500' },
    { city_id: '401', city_name: 'Donggala', postal_code: '94300' },
    { city_id: '402', city_name: 'Morowali', postal_code: '94900' },
    { city_id: '403', city_name: 'Morowali Utara', postal_code: '94900' },
    { city_id: '404', city_name: 'Palu', postal_code: '94100' },
    { city_id: '405', city_name: 'Parigi Moutong', postal_code: '94400' },
    { city_id: '406', city_name: 'Poso', postal_code: '94600' },
    { city_id: '407', city_name: 'Sigi', postal_code: '94364' },
    { city_id: '408', city_name: 'Tojo Una-Una', postal_code: '94683' },
    { city_id: '409', city_name: 'Toli-Toli', postal_code: '94500' },
  ],
  '29': [
    { city_id: '410', city_name: 'Bombana', postal_code: '93700' },
    { city_id: '411', city_name: 'Buton', postal_code: '93700' },
    { city_id: '412', city_name: 'Buton Selatan', postal_code: '93700' },
    { city_id: '413', city_name: 'Buton Tengah', postal_code: '93700' },
    { city_id: '414', city_name: 'Buton Utara', postal_code: '93700' },
    { city_id: '415', city_name: 'Kendari', postal_code: '93100' },
    { city_id: '416', city_name: 'Kolaka', postal_code: '93500' },
    { city_id: '417', city_name: 'Kolaka Timur', postal_code: '93500' },
    { city_id: '418', city_name: 'Kolaka Utara', postal_code: '93600' },
    { city_id: '419', city_name: 'Konawe', postal_code: '93400' },
    { city_id: '420', city_name: 'Konawe Kepulauan', postal_code: '93400' },
    { city_id: '421', city_name: 'Konawe Selatan', postal_code: '93300' },
    { city_id: '422', city_name: 'Konawe Utara', postal_code: '93400' },
    { city_id: '423', city_name: 'Muna', postal_code: '93600' },
    { city_id: '424', city_name: 'Muna Barat', postal_code: '93600' },
    { city_id: '425', city_name: 'Wakatobi', postal_code: '93700' },
  ],
  '30': [
    { city_id: '426', city_name: 'Bitung', postal_code: '95500' },
    { city_id: '427', city_name: 'Bolaang Mongondow', postal_code: '95700' },
    { city_id: '428', city_name: 'Bolaang Mongondow Selatan', postal_code: '95791' },
    { city_id: '429', city_name: 'Bolaang Mongondow Timur', postal_code: '95791' },
    { city_id: '430', city_name: 'Bolaang Mongondow Utara', postal_code: '95791' },
    { city_id: '431', city_name: 'Kepulauan Sangihe', postal_code: '95800' },
    { city_id: '432', city_name: 'Kepulauan Siau Tagulandang Biaro', postal_code: '95800' },
    { city_id: '433', city_name: 'Kepulauan Talaud', postal_code: '95900' },
    { city_id: '434', city_name: 'Kotamobagu', postal_code: '95700' },
    { city_id: '435', city_name: 'Manado', postal_code: '95100' },
    { city_id: '436', city_name: 'Minahasa', postal_code: '95300' },
    { city_id: '437', city_name: 'Minahasa Selatan', postal_code: '95600' },
    { city_id: '438', city_name: 'Minahasa Tenggara', postal_code: '95600' },
    { city_id: '439', city_name: 'Minahasa Utara', postal_code: '95300' },
    { city_id: '440', city_name: 'Tomohon', postal_code: '95362' },
  ],
  '31': [
    { city_id: '441', city_name: 'Agam', postal_code: '26400' },
    { city_id: '442', city_name: 'Bukittinggi', postal_code: '26100' },
    { city_id: '443', city_name: 'Dharmasraya', postal_code: '27600' },
    { city_id: '444', city_name: 'Kepulauan Mentawai', postal_code: '25700' },
    { city_id: '445', city_name: 'Lima Puluh Kota', postal_code: '26600' },
    { city_id: '446', city_name: 'Padang', postal_code: '25100' },
    { city_id: '447', city_name: 'Padang Panjang', postal_code: '27100' },
    { city_id: '448', city_name: 'Padang Pariaman', postal_code: '25500' },
    { city_id: '449', city_name: 'Pariaman', postal_code: '25500' },
    { city_id: '450', city_name: 'Pasaman', postal_code: '26300' },
    { city_id: '451', city_name: 'Pasaman Barat', postal_code: '26300' },
    { city_id: '452', city_name: 'Payakumbuh', postal_code: '26200' },
    { city_id: '453', city_name: 'Pesisir Selatan', postal_code: '25600' },
    { city_id: '454', city_name: 'Sawah Lunto', postal_code: '27400' },
    { city_id: '455', city_name: 'Sijunjung', postal_code: '27500' },
    { city_id: '456', city_name: 'Solok', postal_code: '27300' },
    { city_id: '457', city_name: 'Solok Selatan', postal_code: '27700' },
    { city_id: '458', city_name: 'Tanah Datar', postal_code: '27200' },
  ],
  '32': [
    { city_id: '459', city_name: 'Banyuasin', postal_code: '30700' },
    { city_id: '460', city_name: 'Empat Lawang', postal_code: '31500' },
    { city_id: '461', city_name: 'Lahat', postal_code: '31400' },
    { city_id: '462', city_name: 'Lubuklinggau', postal_code: '31600' },
    { city_id: '463', city_name: 'Muara Enim', postal_code: '31300' },
    { city_id: '464', city_name: 'Musi Banyuasin', postal_code: '30700' },
    { city_id: '465', city_name: 'Musi Rawas', postal_code: '31600' },
    { city_id: '466', city_name: 'Musi Rawas Utara', postal_code: '31600' },
    { city_id: '467', city_name: 'Ogan Ilir', postal_code: '30800' },
    { city_id: '468', city_name: 'Ogan Komering Ilir', postal_code: '30600' },
    { city_id: '469', city_name: 'Ogan Komering Ulu', postal_code: '32100' },
    { city_id: '470', city_name: 'Ogan Komering Ulu Selatan', postal_code: '32200' },
    { city_id: '471', city_name: 'Ogan Komering Ulu Timur', postal_code: '32300' },
    { city_id: '472', city_name: 'Pagar Alam', postal_code: '31500' },
    { city_id: '473', city_name: 'Palembang', postal_code: '30100' },
    { city_id: '474', city_name: 'Penukal Abab Lematang Ilir', postal_code: '31300' },
    { city_id: '475', city_name: 'Prabumulih', postal_code: '31100' },
  ],
  '33': [
    { city_id: '476', city_name: 'Asahan', postal_code: '21200' },
    { city_id: '477', city_name: 'Batubara', postal_code: '21600' },
    { city_id: '478', city_name: 'Binjai', postal_code: '20700' },
    { city_id: '479', city_name: 'Dairi', postal_code: '22200' },
    { city_id: '480', city_name: 'Deli Serdang', postal_code: '20500' },
    { city_id: '481', city_name: 'Gunungsitoli', postal_code: '22800' },
    { city_id: '482', city_name: 'Humbang Hasundutan', postal_code: '22457' },
    { city_id: '483', city_name: 'Karo', postal_code: '22100' },
    { city_id: '484', city_name: 'Labuhanbatu', postal_code: '21400' },
    { city_id: '485', city_name: 'Labuhanbatu Selatan', postal_code: '21400' },
    { city_id: '486', city_name: 'Labuhanbatu Utara', postal_code: '21400' },
    { city_id: '487', city_name: 'Langkat', postal_code: '20800' },
    { city_id: '488', city_name: 'Mandailing Natal', postal_code: '22900' },
    { city_id: '489', city_name: 'Medan', postal_code: '20100' },
    { city_id: '490', city_name: 'Nias', postal_code: '22800' },
    { city_id: '491', city_name: 'Nias Barat', postal_code: '22865' },
    { city_id: '492', city_name: 'Nias Selatan', postal_code: '22865' },
    { city_id: '493', city_name: 'Nias Utara', postal_code: '22865' },
    { city_id: '494', city_name: 'Padang Lawas', postal_code: '22700' },
    { city_id: '495', city_name: 'Padang Lawas Utara', postal_code: '22700' },
    { city_id: '496', city_name: 'Padangsidimpuan', postal_code: '22700' },
    { city_id: '497', city_name: 'Pakpak Bharat', postal_code: '22272' },
    { city_id: '498', city_name: 'Pematangsiantar', postal_code: '21100' },
    { city_id: '499', city_name: 'Samosir', postal_code: '22393' },
    { city_id: '500', city_name: 'Serdang Bedagai', postal_code: '20900' },
    { city_id: '501', city_name: 'Sibolga', postal_code: '22500' },
    { city_id: '502', city_name: 'Simalungun', postal_code: '21100' },
    { city_id: '503', city_name: 'Tapanuli Selatan', postal_code: '22700' },
    { city_id: '504', city_name: 'Tapanuli Tengah', postal_code: '22600' },
    { city_id: '505', city_name: 'Tapanuli Utara', postal_code: '22300' },
    { city_id: '506', city_name: 'Tanjung Balai', postal_code: '21300' },
    { city_id: '507', city_name: 'Tebing Tinggi', postal_code: '20600' },
    { city_id: '508', city_name: 'Toba Samosir', postal_code: '22300' },
  ],
  '34': [
    { city_id: '509', city_name: 'Aceh Barat', postal_code: '23600' },
    { city_id: '510', city_name: 'Aceh Barat Daya', postal_code: '23700' },
    { city_id: '511', city_name: 'Aceh Besar', postal_code: '23900' },
    { city_id: '512', city_name: 'Aceh Jaya', postal_code: '23654' },
    { city_id: '513', city_name: 'Aceh Selatan', postal_code: '23700' },
    { city_id: '514', city_name: 'Aceh Singkil', postal_code: '24785' },
    { city_id: '515', city_name: 'Aceh Tamiang', postal_code: '24400' },
    { city_id: '516', city_name: 'Aceh Tengah', postal_code: '24500' },
    { city_id: '517', city_name: 'Aceh Tenggara', postal_code: '23600' },
    { city_id: '518', city_name: 'Aceh Timur', postal_code: '24400' },
    { city_id: '519', city_name: 'Aceh Utara', postal_code: '24300' },
    { city_id: '520', city_name: 'Banda Aceh', postal_code: '23100' },
    { city_id: '521', city_name: 'Bener Meriah', postal_code: '24600' },
    { city_id: '522', city_name: 'Bireuen', postal_code: '24200' },
    { city_id: '523', city_name: 'Gayo Lues', postal_code: '24600' },
    { city_id: '524', city_name: 'Langsa', postal_code: '24400' },
    { city_id: '525', city_name: 'Lhokseumawe', postal_code: '24300' },
    { city_id: '526', city_name: 'Nagan Raya', postal_code: '23600' },
    { city_id: '527', city_name: 'Pidie', postal_code: '24100' },
    { city_id: '528', city_name: 'Pidie Jaya', postal_code: '24100' },
    { city_id: '529', city_name: 'Sabang', postal_code: '23500' },
    { city_id: '530', city_name: 'Simeulue', postal_code: '23800' },
    { city_id: '531', city_name: 'Subulussalam', postal_code: '24882' },
  ],
};

const USE_MOCK = !process.env.RAJAONGKIR_KEY || process.env.RAJAONGKIR_KEY === 'YOUR_API_KEY';

// V2 tidak punya daftar provinsi/kota; dua fungsi ini hanya melayani data mock (mode tanpa key).
const getProvinces = async () => MOCK_PROVINCES;
const getCities = async (provinceId) => MOCK_CITIES[provinceId] || [];

// Cache hasil pencarian destinasi (kuota paket Starter hanya 100 hit/hari). Kunci: kata pencarian huruf kecil.
const DEST_CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const DEST_CACHE_MAX = 500;
const destCache = new Map();

// Bentuk hasil sama dengan V2: { id, label, province_name, city_name, district_name, subdistrict_name, zip_code }
const searchMockDestinations = (search) => {
  const q = search.toLowerCase();
  const out = [];
  MOCK_PROVINCES.forEach(p => {
    (MOCK_CITIES[p.province_id] || []).forEach(c => {
      if (c.city_name.toLowerCase().includes(q) || p.province.toLowerCase().includes(q)) {
        out.push({
          id: Number(c.city_id), label: `${c.city_name}, ${p.province}`,
          province_name: p.province, city_name: c.city_name,
          district_name: '', subdistrict_name: '', zip_code: c.postal_code || ''
        });
      }
    });
  });
  return out.slice(0, 20);
};

const searchDestinations = async (search) => {
  const keyword = String(search || '').trim().toLowerCase();
  if (keyword.length < 3) return [];
  if (USE_MOCK) return searchMockDestinations(keyword);

  const cached = destCache.get(keyword);
  if (cached && Date.now() - cached.at < DEST_CACHE_TTL_MS) return cached.data;

  try {
    const res = await axios.get(`${BASE_URL}/destination/domestic-destination`, {
      params: { search: keyword, limit: 20, offset: 0 },
      headers: { key: RAJAONGKIR_KEY },
      timeout: REQUEST_TIMEOUT_MS
    });
    const data = Array.isArray(res.data?.data) ? res.data.data : [];
    if (destCache.size >= DEST_CACHE_MAX) destCache.delete(destCache.keys().next().value);
    destCache.set(keyword, { at: Date.now(), data });
    return data;
  } catch (err) {
    // 404 = tidak ada lokasi yang cocok (bukan kesalahan); selain itu catat supaya mudah ditelusuri
    if (err.response?.status !== 404) {
      console.error('RajaOngkir destinasi gagal:', err.response?.status || err.message);
    }
    return [];
  }
};

// Mengembalikan daftar layanan dalam bentuk lama: [{ service, description, cost: [{ value, etd, note }] }]
// supaya utils/shipping.js, order.controller.js, dan CheckoutPage tidak perlu berubah.
const COD_SERVICE = [
  { service: 'COD', description: 'Cash on Delivery - Owner antar langsung', cost: [{ value: 0, etd: '1', note: 'Area tertentu' }] }
];

const getCost = async (destination, weight, courier) => {
  // COD ditangani sendiri (ongkir 0), tidak ada di RajaOngkir
  if (String(courier).toLowerCase() === 'cod') return COD_SERVICE;

  if (USE_MOCK) {
    const baseCost = {
      jne: [
        { service: 'OKE', description: 'Ongkos Kirim Ekonomis', cost: [{ value: 15000, etd: '4-6', note: '' }] },
        { service: 'REG', description: 'Layanan Reguler', cost: [{ value: 22000, etd: '2-3', note: '' }] },
        { service: 'YES', description: 'Yakin Esok Sampai', cost: [{ value: 45000, etd: '1-1', note: '' }] }
      ],
      jnt: [
        { service: 'EZ', description: 'J&T EZ', cost: [{ value: 18000, etd: '2-4', note: '' }] },
        { service: 'EXPRESS', description: 'J&T Express', cost: [{ value: 25000, etd: '1-2', note: '' }] }
      ],
      sicepat: [
        { service: 'HALU', description: 'SiCepat Halu', cost: [{ value: 20000, etd: '2-4', note: '' }] },
        { service: 'BEST', description: 'SiCepat Best', cost: [{ value: 30000, etd: '1-2', note: '' }] }
      ],
      cod: [
        { service: 'COD', description: 'Cash on Delivery - Owner antar langsung', cost: [{ value: 0, etd: '1', note: 'Area tertentu' }] }
      ]
    };
    return baseCost[courier.toLowerCase()] || baseCost.jne;
  }

  if (!ORIGIN_ID) {
    console.error('RAJAONGKIR_ORIGIN_ID belum diisi: ongkir tidak bisa dihitung dengan key asli');
    return [];
  }

  try {
    const body = new URLSearchParams({
      origin: String(ORIGIN_ID),
      destination: String(destination),
      weight: String(Math.max(1, Math.round(weight))),
      courier: String(courier).toLowerCase()
    });
    const res = await axios.post(`${BASE_URL}/calculate/domestic-cost`, body.toString(), {
      headers: { key: RAJAONGKIR_KEY, 'Content-Type': 'application/x-www-form-urlencoded' },
      timeout: REQUEST_TIMEOUT_MS
    });
    const rows = Array.isArray(res.data?.data) ? res.data.data : [];
    // JNE Trucking (JTR*) untuk barang berat; tidak relevan untuk decant (50 g per botol), jadi disembunyikan
    return rows.filter(r => !/^JTR/i.test(String(r.service || ''))).map(r => ({
      service: r.service,
      description: r.description || r.service,
      cost: [{ value: Number(r.cost), etd: String(r.etd || '').replace(/\s*(days?|hari)\b/gi, '').trim(), note: '' }] // frontend menambah kata "hari"
    }));
  } catch (err) {
    // 400 = tarif tidak ditemukan untuk rute/kurir ini, 422 = kode kurir tidak valid
    console.error('RajaOngkir ongkir gagal:', err.response?.status || err.message);
    return [];
  }
};

module.exports = { getProvinces, getCities, getCost, searchDestinations };
